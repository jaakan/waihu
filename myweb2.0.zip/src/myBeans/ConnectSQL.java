package myBeans;
import java.sql.*;
import java.util.*;
import java.io.*;

public class ConnectSQL {

	/**
	 * @param args
	 */

	private Connection con=null;
	private Statement state=null;
	private SQLConnectInfo info=null;
	private String driver="com.mysql.jdbc.Driver";
	
	public ConnectSQL(String dbname){
		info=new SQLConnectInfo();
		info.init(dbname);
	}
	
	
	public void init(){
		
		
		//String url="jdbc:mysql://localhost:3306/myweb";
		//String sqlname="root";
		//String sqlpass="sunkai";
		String url=info.getURL();
		String sqlname=info.getUsername();
		String sqlpass=info.getPassword();
		try {
			Class.forName(driver);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		this.setConnection(url,sqlname,sqlpass);
		this.setStatement();
		
	}
	
	private void setConnection(String url, String name,String passwd){
		try {
			con=DriverManager.getConnection(url,name,passwd);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	private void setStatement(){
		try {
			state=con.createStatement();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public SQLConnectInfo setInfo(String url,String username,String password){
		this.info.setInfo(url, username, password);
		return this.info;
	}
	
	public Connection getConnection(){
		return this.con;
	}
	
	
	
	
	public Statement getStatement(){
		this.setStatement();
		return this.state;
	}
	
	public void close(){
		try {
			this.state.close();
			this.con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	public  int upDate(String sql){
		this.setStatement();
		int s=0;
		try {
			s = state.executeUpdate(sql);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return s;
	}
	
	public ResultSet getResult(String SQL){
		this.setStatement();
		ResultSet re=null;
		try {
			re = state.executeQuery(SQL);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return re;
	}
	
	public SQLConnectInfo getSQLConnectInfo(){
		return this.info;
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ConnectSQL con=new ConnectSQL("myweb");
		
	//	System.out.print(con.setInfo("jdbc:mysql://localhost:3306","root","123456").getURL());
		con.init();
		String sql="show databases";
		ResultSet rs=con.getResult(sql);
		try {
			ResultSetMetaData rsmd=rs.getMetaData();
			//int size=rsmd.getColumnCount();
			//for(int i=1;i<=size;i++){
				//System.out.print("i"+i+":"+rsmd.getColumnName(i)+"<<<<<<<<\t");
			//}
			System.out.println("");
			while(rs.next()){
				//for(int j=1;j<=size;j++){
					System.out.print(rs.getString(1)+">>>>>>>>\t");
				//}
				System.out.println("");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}

