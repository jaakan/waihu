package myBeans;
import java.io.*;
import java.net.URISyntaxException;
import java.util.*;

import org.json.*;

import myBeans.*;


public class SQLConnectInfo {
	
	
	private File root=null;
	private File infoDir=null;
    private File infoFile=null;
    private JSONObject json=null;
    private boolean hadFile=false;
    private String dbname=null;
    private GetRootPath rootPath=null;
 
    
	
	public  void init(String dbname){
		this.dbname=dbname;
		rootPath=new GetRootPath("myweb2.0");
		root=new File(rootPath.rootPath);
		infoDir=new File(root,"DBInfo");
		infoFile=new File(infoDir,dbname+".json");
		
	}
	
	
	
	private boolean createInfoFile(String url,String username,String password){
		boolean success=true;
		try{
			//��������ļ������ļ����Ƿ���ڣ�������������;
			if(!infoDir.exists()){
				infoDir.mkdir();
			}
				//��ʼ�������ļ�;
				json=new JSONObject();
				try {
					json.put("dbname",this.dbname);
					json.put("url",url+"/"+this.dbname);
					json.put("username",username);
					json.put("password",password);
				} catch (JSONException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					success=false;
				}
				
				WriteJson writer=new WriteJson();
				writer.setFile(infoFile);
				writer.writeJsonData(json.toString());
				
		}catch(Exception e){
			success=false;
		}
		return success;
		
	}
	
	public JSONObject getInfo(){
		JSONObject _json=null;
		ReadJson reader=new ReadJson();
		reader.setFile(infoFile);
		
		//��INFO�ļ������ڣ�����createInfoFile�����ļ���
		if(!infoFile.exists()){
			this.createInfoFile(
					"jdbc:mysql://localhost:3306", 
					"username", 
					"password");
			_json=json;
		}else{
			try {
				json=new JSONObject(reader.getJsonData());
				_json=json;
			} catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return _json;
	}
	
	public void setInfo(String url,String username,String password){
		createInfoFile(url,username,password);
	}
	
	public String getURL(){
		String _url=null;
		try {
			 _url=this.getInfo().getString("url");
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return _url;
	}
	
	public String getUsername(){
		String _username=null;
		try {
			 _username=this.getInfo().getString("username");
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return _username;
	}
	
	public String getPassword(){
		String _password=null;
		try {
			_password=this.getInfo().getString("password");
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return _password;
	}
	
	//��������ļ��Ƿ���ڣ�
	public boolean isExist(){
		this.hadFile=this.infoFile.exists();
		return this.hadFile;
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SQLConnectInfo info=new SQLConnectInfo();
		info.init("myweb");
		info.setInfo("httppppppp", "skkkk", "111111111");
		System.out.println(info.getURL());
		System.out.println(info.getUsername());
		System.out.println(info.getPassword());
	}

}
