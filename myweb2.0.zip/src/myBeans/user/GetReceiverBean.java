package myBeans.user;
import java.io.*;
import java.sql.*;
import java.util.ArrayList;

import org.json.*;

import myBeans.ConnectSQL;

public class GetReceiverBean {

	/**
	 * @param args
	 */
	private ConnectSQL con=null;
	private ArrayList<JSONObject> users=new ArrayList<JSONObject>();
	private JSONArray list=null;
	
	public void connect(String dbname){
		this.con=new ConnectSQL(dbname);
	}
	
	public ArrayList<JSONObject> select(String sql){

		con.init();
		ResultSet rs=con.getResult(sql);
		try {
			ResultSetMetaData rsmd=rs.getMetaData();
			int column=rsmd.getColumnCount();
			list=new JSONArray();
			while(rs.next()){
				JSONObject user=new JSONObject();
				for(int i=1;i<=column;i++){
					user.put(rsmd.getColumnName(i),rs.getString(i));
				}
				users.add(user);
				list.put(user);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return users;
	}
	public JSONArray getList(){
		return this.list;
	}
	
	public void close(){
		con.close();
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		GetReceiverBean bean=new GetReceiverBean();
		bean.connect("myweb");
		ArrayList<JSONObject> users=bean.select("select * from user");
		JSONArray list=bean.getList();
		for(int i=0;i<users.size();i++){
			//System.out.println(users.get(i).toString());
			
		}
		System.out.println(list.toString());

	}

}
