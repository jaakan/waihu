package myBeans.user;
import java.sql.*;
import java.io.*;
import java.util.*;
import org.json.*;

import myBeans.*;

public class InitMenuBean {

	/**
	 * @param args
	 */
	private ConnectSQL con=null;
	private JSONArray taskList=null;
	
	public void connect(String dbname){
		con=new ConnectSQL(dbname);
		con.init();
		taskList=new JSONArray();
	}
	
	public void select(){
		String sql="SELECT taskName,maker,receivers FROM taskList";
		ResultSet rs=con.getResult(sql);
		ResultSetMetaData rsmd=null;
		try {
			rsmd=rs.getMetaData();
			int column=rsmd.getColumnCount();
			while(rs.next()){
				JSONObject task=new JSONObject();
				for(int i=1;i<=column;i++){
					task.put(rsmd.getColumnName(i), rs.getString(i));
				}
				taskList.put(task);
			}

		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	public JSONArray getList(){
		return this.taskList;
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		InitMenuBean menu=new InitMenuBean();
		menu.connect("myweb");
		menu.select();
		System.out.print(menu.getList().toString());
		System.out.print(menu.getList().length());

	}

}
