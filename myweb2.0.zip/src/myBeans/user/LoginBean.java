package myBeans.user;
import java.io.*;
import java.sql.*;

import org.json.*;

import myBeans.*;

public class LoginBean {
	/**
	 * @param args
	 */
	private JSONObject user=null;
	private ConnectSQL con=null;
	private String sql=null;
	
	public JSONObject check(String id){
		user=new JSONObject();
		if(!con.getSQLConnectInfo().isExist()){
			con.setInfo("jdbc:mysql://localhost:3306","root","sunkai");
		}
		con.init();
		sql="SELECT * FROM myweb.user WHERE user.id='"+id+"'";
		
		try {
			ResultSet rs=con.getResult(sql);
			ResultSetMetaData rsmd=rs.getMetaData();
			int column=rsmd.getColumnCount();
			while(rs.next()){
				for(int i=1;i<=column;i++){
					user.put(rsmd.getColumnName(i),rs.getString(i));
				}
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return user;
	}
	
	public void connect(String dbname){
		this.con=new ConnectSQL(dbname);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LoginBean log=new LoginBean();
		System.out.print(log.check("616").isNull("name"));

	}

}
