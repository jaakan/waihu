package myBeans.user;
import java.sql.*;
import java.io.*;
import java.util.*;

import myBeans.user.*;
import myBeans.*;
public class UpdateTasklistBean {

	/**
	 * @param args
	 */
	private ConnectSQL con=null;
	
	public void init(String dbname){
		con=new ConnectSQL(dbname);
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
