package test;

public class test {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=3;
		int b=8;
		System.out.println("b/a:"+b/a);
		System.out.println("b%a:"+b%a);

	}

}
